<?php
require("connection.php");
require("validate.php");

$response = new stdClass();


$method = $_POST['method'];

if($method == "get"){
	$response = get($response);
}else if($method == "create"){
	$response = create($response);
}else if($method == "update"){
	$response = update($response);
}else if($method == "delete"){
	$response = delete($response);
}else if($method == "get2"){
	$response = get2($response);
}


$JSONresponse = json_encode($response);
echo $JSONresponse;


function get($response){
	try{

		$conn = getConn();
		$empQ = "SELECT reg.UserId, emp.EmpId, emp.FirstName, emp.LastName, ag.Description, emp.Shift, emp.ContactNo, emp.Email, emp.KPI FROM employee emp, accessgroup ag , register reg WHERE ag.AccessGroupId = emp.AccessGroupId AND emp.UserId=reg.UserId";

		$empQResult = mysqli_query($conn, $empQ);
		
		if($empQResult == 0){
			throw new Exception("Could not execute");
		}
		$mainArray = Array();

		while($row = mysqli_fetch_row($empQResult)){
			$subArray = Array($row[0],$row[1],$row[2],$row[3],$row[4],$row[5],$row[6],$row[7],$row[8]);
			array_push($mainArray, $subArray);
		}

		$response-> success = $mainArray;
		
	}catch(Exception $e){
		$response -> error = $e -> getMessage();
	}finally {
		if($conn){
			mysqli_close($conn);
		}
	}
	return $response;
}

function create($response){
	try{
		$userId = $_POST["userId"];
		$empId = $_POST["empId"];
		$firstName= $_POST["firstName"];
		$lastName=$_POST["lastName"];
		$designation=$_POST["designation"];
		$shift=$_POST["shift"];
        $contactNo=$_POST["contactNo"];
		$email=$_POST["email"];
		$kpi=$_POST["kpi"];
		
		$validateArr = Array();
		array_push($validateArr, Array("userId","User ID",$userId,array("required")));
		array_push($validateArr, Array("empId","Emp ID",$empId,array("required")));
		array_push($validateArr, Array("firstName","First Name",$firstName,array("required")));
		array_push($validateArr, Array("lastName","Last Name",$lastName,array("required")));
        array_push($validateArr, Array("designation","Designation",$designation,array("required")));
        array_push($validateArr, Array("shift","Shift",$shift,array("required")));
		array_push($validateArr, Array("contactNo","Contact No",$contactNo,array("required")));
		array_push($validateArr, Array("email","Email",$email,array("required")));
		array_push($validateArr, Array("kpi","KPI",$kpi,array("required")));

		$result = validate($validateArr);

		if(count($result) > 0){
			$response-> errorList = $result;
		}else{

			$conn = getConn();
			//Get if exist
			$empEQ = "SELECT emp.EmpId FROM employee emp WHERE emp.EmpId='".$empId."'";
			$empEQResult = mysqli_query($conn, $empEQ);
			
			if($empEQResult == 0){
				throw new Exception("Could not execute isExist");
			}else if(mysqli_num_rows($empEQResult) != 0){
				throw new Exception("Employee exists");
			}

			//Insert Query
			$empQ = "INSERT INTO employee (UserId,EmpId,FirstName,LastName,AccessGroupId,Shift,ContactNo,Email,KPI) VALUES ('$userId','$empId','$firstName','$lastName','$designation','$shift','$contactNo','$email','$kpi')";

			$empQResult = mysqli_query($conn, $empQ);
			
			if($empQResult == 0){
				throw new Exception("Could not execute");
			}
			
			$response-> success = "Employee successfully created";
		}
	}catch(Exception $e){
		$response -> error = $e -> getMessage();
	}finally {
		if($conn){
			mysqli_close($conn);
		}
	}
	return $response;
}

function update($response){
	try{
		$userId = $_POST["userId"];
        $empId = $_POST["empId"];
		$firstName= $_POST["firstName"];
		$lastName=$_POST["lastName"];
		$designation=$_POST["designation"];
		$shift=$_POST["shift"];
        $contactNo=$_POST["contactNo"];
		$email=$_POST["email"];
		$kpi=$_POST["kpi"];
		
		$validateArr = Array();
		array_push($validateArr, Array("userId","User ID",$userId,array("required")));
		array_push($validateArr, Array("empId","Emp ID",$empId,array("required")));
		array_push($validateArr, Array("firstName","First Name",$firstName,array("required")));
		array_push($validateArr, Array("lastName","Last Name",$lastName,array("required")));
        array_push($validateArr, Array("designation","Designation",$designation,array("required")));
        array_push($validateArr, Array("shift","Shift",$shift,array("required")));
		array_push($validateArr, Array("contactNo","Contact No",$contactNo,array("required")));
		array_push($validateArr, Array("email","Email",$email,array("required")));
        array_push($validateArr, Array("kpi","KPI",$kpi,array("required")));
		
		$result = validate($validateArr);


		if(count($result) > 0){
			$response-> errorList = $result;
		}else{

			$conn = getConn();

			$empQ = "SELECT reg.UserId, emp.EmpId, emp.FirstName, emp.LastName, ag.Description, emp.Shift, emp.ContactNo, emp.Email, emp.KPI FROM employee emp, accessgroup ag, register reg WHERE ag.AccessGroupId = emp.AccessGroupId AND emp.UserId = reg.UserId";


			$empQResult = mysqli_query($conn, $empQ);
			
			if($empQResult == 0){
				throw new Exception("Could not execute in SELECT");
			}else if(mysqli_num_rows($empQResult) == 0){
				throw new Exception("Employee not found");
			}

			/*$empQ = "SELECT emp.Name, emp.EmpID, emp.UserName, ag.Description, emp.Shift, emp.UserId, emp.AccessGroupId FROM employee emp, access_group ag WHERE ag.AccessGroupId != emp.AccessGroupId";
			$empQResult = mysqli_query($conn, $empQ);
			
			if($empQResult == 0){
				throw new Exception("Could not execute");
			}else if(mysqli_num_rows($empQResult) != 0){
				throw new Exception("Employee exists");
			}*/

			$empQ = "UPDATE employee SET FirstName='".$firstName."', LastName='".$lastName."', AccessGroupId=$designation, Shift='".$shift."',ContactNo='".$contactNo."', Email='".$email."', KPI='".$kpi."' WHERE EmpId=$empId";
			
			$empQResult = mysqli_query($conn, $empQ);
			
			if($empQResult == 0){
				throw new Exception("Could not execute");
			}
			
			$response-> success = "Employee successfully updated";
		}
	}catch(Exception $e){
		$response -> error = $e -> getMessage();
	}finally {
		if($conn){
			mysqli_close($conn);
		}
	}
	return $response;
}

function delete($response){
	try{
		$empId = $_POST["empId"];

		$conn = getConn();

		$empQ = "DELETE FROM employee WHERE EmpId = $empId";
		$empQResult = mysqli_query($conn, $empQ);
		
		if($empQResult == 0){
			throw new Exception("Could not execute");
		}
		
		$response-> success = "Employee successfully deleted";
		
	}catch(Exception $e){
		$response -> error = $e -> getMessage();
	}finally {
		if($conn){
			mysqli_close($conn);
		}
	}
	return $response;
}

?>
