<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	  <script src="coats.js"></script>
     <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="modules/bootstrap/dist/css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="modules/font-awesome/css/font-awesome.min.css">
    <style type="text/css">
 
/* .logo{
  width: 80px;
  height: 80px;
  position:absolute;
  top: 3%;
  left:45%;
  padding-bottom: 10px;
} */
h1{
  margin:0;
  padding: 0 0 1px;
  text-align: center;
  font-size: 22px;
}
h2{
  margin:0;
  padding: 0 0 5px;
  text-align: center;
  font-size: 15px;
}

h3{
  border-top: 1px solid #C0C0C0;
  border-bottom:1px solid #C0C0C0;
  border-left: 600px;
  border-right: 600px;
  margin:0;
  padding: 0 0 5px;
  text-align: center;
  font-size: 15px;
}
.modal {
	/*display: none; Hidden by default */
	position: fixed; /* Stay in place */
    z-index: 2000; /* Sit on top */
	padding-top: 100px; /* Location of the box */
	left: 0;
	top: 0;
	width: 100%; /* Full width */
	height: 100%; /* Full height */
	overflow: auto; /* Enable scroll if needed */
	background-color: rgb(0,0,0); /* Fallback color */
	background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    }

    /* Modal Content */
	.modal-content {
	background-color: #0099ff;
	margin: 100px;
    margin-left: 400px;
	padding: 20px 25px 10px;
	border: 1px solid #888;
	width: 100%;
    }
    h3{
    border-top: 1px solid #C0C0C0;
    border-bottom:1px solid #C0C0C0;
    border-left: 600px;
    border-right: 600px;
    margin:0;
    padding: 0 0 5px;
    text-align: center;
    font-size: 15px;
    }
    .options input[type="submit"]{
    border: none;
	outline: none;
	height: 40px;
	width: 100px;
	background:#00008B;
	color:#fff;
	font-size: 14px;
	font-weight: bold;
	margin-left: 20%;
	align-items: justify;
	margin-top: 3%;			
    }
	.options input[type="button"]{
	border: none;
	outline: none;
	height: 40px;
	width: 100px;
	background:#00008B;
	color:#fff;
	font-size: 14px;
	font-weight: bold;
	margin-left: 5%;
	}
	.options input[type="submit"]:hover{
	cursor: pointer;
	background: #0000FF;
	color: #000;
	}
	.options input[type="button"]:hover{
	cursor: pointer;
	background: #0000FF;
	color: #000;
	}

</style>

</head>

<body>
    <div class="col-12">
        <div class="col-12 col-sm-5 offset-3">
            <!-- <div class="row row-content">
                <img src="logo.bmp" class="logo">
            </div> -->
            <!-- Modal content-->
	      	<div class="modal-content">
                <form class="form-content" method="post" action="validate.php">
                    <div class="col-12">
                    <h1>Coats Thread Exports Pvt(Ltd)</h1><br>
                    <h2>Factory,Moragahahena,Millewa,<br>Horana</h2><br>
                    <h3>LOGIN</h3>
            
                    </div><br>    
                    <div class="form-group row">
                        <label for="userName" class="col-12 col-md-3 col-form-label"> User Name</label>
                        <div class="col-md-8">
                            <input type="text" class="form-control" id="userName" name="userName" placeholder="User Name">

                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="password" class="col-12 col-md-3 col-form-label"> Password</label>
                        <div class="col-md-8">
                            <input type="text" class="form-control" id="password" name="password" placeholder="Password">
                        </div>
                    </div>
                    <div class="form-group row">
                            <button type="button" class="btn btn-secondary btn-lg ml-auto" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary btn-lg ml-1" onclick="crudOption=1;confsubmit();" id="login">Sign In</button>
                    </div>
                </form>               
            </div>
        </div>
    </div>

    <script type="text/javascript">
        function submit(){
            userName = document.getElementById("userName").value;
            password = document.getElementById("password").value;

            //form data declaration
            formData = new FormData();
            //add username and password to form data
            formData.append("userName",userName);
            formData.append("password",password);

            //ajax function
            xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function(){
                if (this.readyState == 4 && this.status == 200){
                    resp = JSON.parse(this.responseText);
                    if(resp["error"]){
                        document.getElementById("errorDiv").innerHTML = resp["error"];

                    }else{
                        window.location = resp["success"]
                    }
                }
            };

            //set http method POST and url
            xhttp.open("post","loginController.php",true);
            //append form data to send to controller
            xhttp.send(formData);

        }
    </script>                                       
</body>
</html>
