<?php

session_start();
$_SESSION['message']='';
$mysqli=new mysqli('localhost','root','','coats');
    
require("connection.php");
require("validate.php");


			$costcenterId = $mysqli->real_escape_string($_POST["costcenterId"]);	
            $name = $mysqli->real_escape_string($_POST['name']);

			//get DB connection instance and execute query
            $conn = getConn();
            $_SESSION['userName']=$userName;

			$ccQ = "INSERT INTO costcenter (CostCenterId, Description) VALUES ('$costcenterId','$name')";
            $ccQResult = mysqli_query($conn, $ccQ);
            
            if ($mysqli->query($ccQResult)==true) {
                $_SESSION['message']="Submission successful!";
			    header("location:home.php");
		    }else{
			    $_SESSION['message']="Submission failed.";
            }
?>