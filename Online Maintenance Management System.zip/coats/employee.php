<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<script src="coats.js"></script>
     <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="modules/bootstrap/dist/css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="modules/font-awesome/css/font-awesome.min.css">

    <!-- <link rel="stylesheet" href="modules/bootstrap-social/bootstrap-social.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.17.1/dist/bootstrap-table.min.css">
    
    <link rel="stylesheet" href="modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="modules/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="modules/bootstrap-social/bootstrap-social.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.17.1/dist/bootstrap-table.min.css"> -->
    <!-- <link rel="stylesheet" href="./dt2/Bootstrap-4-4.1.1/css/datatables.min.css">
    <link rel="stylesheet" href="./dt2/bootstrap.min.css"> -->

		<style>
			.tableDiv{
				background-color: white;

			}

			.modal {
				display: none; /* Hidden by default */
				position: fixed; /* Stay in place */
				z-index: 2000; /* Sit on top */
				padding-top: 100px; /* Location of the box */
				left: 0;
				top: 0;
				width: 100%; /* Full width */
				height: 100%; /* Full height */
				overflow: auto; /* Enable scroll if needed */
				background-color: rgb(0,0,0); /* Fallback color */
				background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
			}

			/* Modal Content */
			.modal-content {
				background-color: #fefefe;
				margin: auto;
				padding: 20px;
				border: 1px solid #888;
				width: 100%;
			}

			/* The Close Button */
			.close {
				color: #aaaaaa;
				float: right;
				font-size: 28px;
				font-weight: bold;
			}

			.close:hover,
			.close:focus {
				color: #000;
				text-decoration: none;
				cursor: pointer;
			}
		</style>
		
</head>


<body>
    <div class="container">
        <div class="row">
            <ol class="col-12 breadcrumb">
                <li class="breadcrumb-item"><a href="./home.php">Home</a></li>
                <li class="breadcrumb-item active">Employee</li>
            </ol>
            <div class="col-12">
            	<h3>Employee Details</h3>
			</div>
		</div>
		<div class="col-12">
			<div class="options">
				<!-- <input type="button" onclick="crudOption=1;confCrud();" id="submit" value="Submit">
				<input type="button" onclick="clearAll();" id="refresh" value="Refresh"> -->
				<button type="button" class="btn btn-primary" onclick="crudOption=2;confCrud();"  id="update">Update</button>
				<button type="button" class="btn btn-primary" onclick="crudOption=3;confCrud();"  id="delete">Delete</button>
			</div>
		</div>
            <div class="col-12 tableDiv">
                <table id="tab" class="table table-striped table-bordered" style="width:100%"></table>
                <!-- <a class="btn btn-block btn-sm btn-success" role="button" id="addbtn"><b>Add</b></a> -->
                <button type="button" class="btn btn-block btn-sm btn-success" data-toggle="modal" data-target="#myModal">Open Modal</button>
            </div>
    </div>

    <!-- Modal -->
	<!-- Modal -->
		<div class="modal fade modal-lg" id="myModal" role="dialog">
	    	<div class="modal-dialog">
	    
					<!-- Modal content-->
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">Fill out your details</h4>
						</div>
						<div class="modal-body">	
				
							<!-- <form> -->
							<div class="form-group row">
								<label for="userId" class="col-12 col-md-4 col-form-label">User ID</label>
									<div class="col-md-10">
										<input type="text" class="form-control" id="userId" name="userId" placeholder="User ID">
									</div>
							</div>
							<div class="form-group row">
								<label for="empId" class="col-12 col-md-4 col-form-label">Emp ID</label>
									<div class="col-md-10">
										<input type="text" class="form-control" id="empId" name="empId" placeholder="Employee ID">	
									</div>
							</div>
							<div class="form-group row">
								<label for="firstName" class="col-12 col-md-4 col-form-label">First Name</label>
									<div class="col-md-10">
										<input type="text" class="form-control" id="firstName" name="firstName" placeholder="First Name">
									</div>
							</div>
							<div class="form-group row">
								<label for="lastName" class="col-12 col-md-4 col-form-label">Last Name</label>
									<div class="col-md-10">	
										<input type="text" class="form-control" id="lastName" name="lastName" placeholder="Last Name">
									</div>
							</div>
							<div class="form-group row">
								<label for="designation" class="col-12 col-md-4 col-form-label" id="designation">Designation</label>
									<div class="col-md-5">	
										<select class="form-control">
											<option>Manager</option>
											<option>Engineer</option>
											<option>Technician</option>
										</select>
									</div>
							</div>
							<div class="form-group row">
								<label for="shift" class="col-12 col-md-4 col-form-label" id="shift">Shift</label>
									<div class="col-md-5">
										<select class="form-control">
											<option>A</option>
											<option>B</option>
											<option>C</option>
											<option>D</option>
										</select>
									</div>
							</div>
							<div class="form-group row">
								<label for="contactNo" class="col-12 col-md-4 col-form-label">Contact No</label>
									<div class="col-md-10">
										<input type="contactNo" class="form-control" id="contactNo" name="contactNo" placeholder="Contact No">	
									</div>
							</div>
							<div class="form-group row">
								<label for="email" class="col-12 col-md-4 col-form-label">Email</label>
									<div class="col-md-10">
										<input type="email" class="form-control" id="email" name="email" placeholder="Email">	
									</div>
							</div>
							<div class="form-group row">
								<label for="kpi" class="col-12 col-md-4 col-form-label">KPI</label>
									<div class="col-md-10">
										<input type="number" class="form-control" id="kpi" name="kpi" placeholder="KPI">	
									</div>
							</div>
							<!-- </form> -->	
							<div class="form-group row">
								<div class="offset-md-2 col-md-10">
									<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>   	
									<button type="submit" class="btn btn-primary" onclick="crudOption=1;confCrud();" id="submit">Add Details</button>
								</div>
							</div>
						</div>
						<div class="modal-footer">	
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						</div>
					</div>	
	      
	    	</div>
	  	</div>

    <!-- <div class="addModal" id="addModal" class="modal fade" role="dialog">
        <div class="modal-dialog modal-lg" role="content">    
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Fill out your details</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="col-12 col-md-9">
                    
                </div>
                </div>
            </div>
        </div>
    </div> -->

    <title>COATS: Employee</title>

	<script type="text/javascript" src="./dt2/jquery-3.5.1.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
	<script type="text/javascript" src="./dt2/datatables.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>	
    <script>
		//crudOption 1 = create, 2 = update, 3 = delete
		var crudOption = 0;
		var inputList = ["User ID","Emp ID","First Name","Last Name","Designation","Shift","Contact No","Email","KPI"];

		function clearAll(){
			clearList(inputList);
			$("#shift").val("A");
			$("#designation").val("");
		}

		function crud(){
			var xhttp = new XMLHttpRequest();

			if((crudOption == 2 || crudOption == 3) && $("#empId").val().trim() == ""){
				alertModal("Error", "Please select a record");
				return;
			}

			var formData = new FormData();
			if(crudOption == 1){
				formData.append("method" , "create");
	        }else if(crudOption == 2){
	        	formData.append("method" , "update");
	        }else if(crudOption == 3){
	        	formData.append("method" , "delete");
	        } 

	        if(crudOption == 1 || crudOption == 2){
				formData.append("userId" , $("#userId").val());
				formData.append("empId" , $("#empId").val());
	        	formData.append("firstName" , $("#firstName").val());
				formData.append("lastName" , $("#lastName").val());
				formData.append("designation" , $("#designation").val());
				formData.append("shift" , $("#shift").val());
				formData.append("contactNo" , $("#contactNo").val());
				formData.append("email" , $("#email").val());
				formData.append("kpi" , $("#kpi").val());
	        }
	        if(crudOption == 2 || crudOption == 3){
	        	formData.append("empId" , $("#empId").val());
			}
			///////////////////////////////////////////////////////////////
	        xhttp.onreadystatechange = function() {
	            if (this.readyState == 4 && this.status == 200) {
	                var resp = JSON.parse(this.responseText);
	                if(resp["error"]){
	                    alert("Error : "+resp["error"]);                     
	                }else if(resp["success"]){
	                	alert("Success :"+resp["success"]);
	                	getTableData();
	                	clearAll();
	                }else if(resp["errorList"]){
	                    printErrors(resp["errorList"]);
	                }else{
	                    alert("Error : Unexpected error");
	                }
	           }
	        };
	        xhttp.open("POST", "employeeController.php", true);
	        xhttp.send(formData);
		}

		function getTableData(){
	       	var xhttp = new XMLHttpRequest();

	        var formData = new FormData(); 
			formData.append("method" , "get");
			//////////////////////////////////////////////////////////////////////
            //designation drop down come from another page
	        xhttp.onreadystatechange = function() {
	            if (this.readyState == 4 && this.status == 200) {
	                var resp = JSON.parse(this.responseText);
	                if(resp["error"]){
	                    alert("Error : "+resp["error"]);                          
	                }else if(resp["success"]){
	                	drawTable("tab", resp["success"]);
	                }else if(resp["errorList"]){
	                    printErrors(resp["errorList"]);
	                }else{
	                    alert("Error : Unexpected error");
	                }
	           }
	        };
	        xhttp.open("POST", "employeeController.php", true);
	        xhttp.send(formData);
		}

		function getAccessGroups(){
	       	var xhttp = new XMLHttpRequest();

	        var formData = new FormData(); 
			formData.append("method" , "get");
			///////////////////////////////////////////////////////////////////////
	        xhttp.onreadystatechange = function() {
	            if (this.readyState == 4 && this.status == 200) {
	                var resp = JSON.parse(this.responseText);
	                if(resp["error"]){
	                    alert("Error : "+resp["error"]);                          
	                }else if(resp["success"]){
	                	createSelect("designation", resp["success"]);
	                }else if(resp["errorList"]){
	                    printErrors(resp["errorList"]);
	                }else{
	                    alert("Error : Unexpected error");
	                }
	           }
	        };
	        xhttp.open("POST", "accessGroupController.php", true);
	        xhttp.send(formData);
		}

		let table1 = null;
		function setup(){
			table1 = $('#tab').DataTable( {
		    	data: [],
		        columns: [
                    { title: "User Id"},
		            { title: "Emp ID" },
		            { title: "First Name"},
		            { title: "Last Name"},
		            { title: "Designation"},
		            { title: "Shift"},
                    { title: "Contact No"},
					{ title: "Email"},
					{ title: "KPI"},
		            { title: "Designation Id"}
		        ],
		        columnDefs: [ {"targets": [0,9], "searchable": false, "visible": false} ] 
		    } );
		    
		    $('#tab tbody tr').mouseover(function() {
		    	$(this).addClass('tab-row-hover');
		    });
		    $('#tab tbody tr').mouseout(function() {
		        $(this).removeClass('tab-row-hover');
		    }); 
		   
		    $('#tab tbody').on( 'click', 'tr', function () {
		    	    table1.$('tr.tab-row-selected').removeClass('tab-row-selected');
			        $(this).addClass('tab-row-selected');
		 	        
		 	        var rowData = table1.row( this ).data();
		 	        onRowClick(rowData);
		    	
		    } );

		    function onRowClick(data){
		    	$("#userId").val(data[0]);
                $("#empId").val(data[1]);
		    	$("#firstName").val(data[2]);
		    	$("#lastName").val(data[3]);
		    	$("#designation").val(data[4]);
		    	$("#shift").val(data[5]);
		    	$("#contactNo").val(data[6]);
				$("#email").val(data[7]);
				$("#kpi").val(data[8]);
                $("#designationId").val(data[9]);

                alert(data)

		    }

			getAccessGroups();
			getTableData();
			
		}

        setup();

    </script>
    
</body>
</html>