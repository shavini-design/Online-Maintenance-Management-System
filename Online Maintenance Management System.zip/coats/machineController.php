<?php
require("connection.php");
require("validate.php");

$response = new stdClass();


$method = $_POST['method'];

if($method == "get"){
	$response = get($response);
}else if($method == "create"){
	$response = create($response);
}else if($method == "update"){
	$response = update($response);
}else if($method == "delete"){
	$response = delete($response);
}else if($method == "get2"){
	$response = get2($response);
}


$JSONresponse = json_encode($response);
echo $JSONresponse;


function get($response){
	try{

		$conn = getConn();
		$maQ = "SELECT ma.MachineId, ma.Name, ma.SerialNumber, ma.Manufacturer, ma.YearOfManufactured, cc.Description FROM machine ma, costcenter cc WHERE cc.CostCenterId = ma.CostCenterId";

		$maQResult = mysqli_query($conn, $maQ);
		
		if($maQResult == 0){
			throw new Exception("Could not execute");
		}
		$mainArray = Array();

		while($row = mysqli_fetch_row($maQResult)){
			$subArray = Array($row[0],$row[1],$row[2],$row[3],$row[4],$row[5]);
			array_push($mainArray, $subArray);
		}

		$response-> success = $mainArray;
		
	}catch(Exception $e){
		$response -> error = $e -> getMessage();
	}finally {
		if($conn){
			mysqli_close($conn);
		}
	}
	return $response;
}

function create($response){
	try{
		$machineId = $_POST["machineId"];
		$name= $_POST["name"];
		$serialNumber=$_POST["serialNumber"];
		$manufacturer=$_POST["manufacturer"];
		$yearOfManufactured=$_POST["yearOfManufactured"];
        $costCenter=$_POST["costCenter"];
		
		$validateArr = Array();
		array_push($validateArr, Array("machineId","Machine ID",$machineId,array("required")));
		array_push($validateArr, Array("name","Name",$name,array("required")));
		array_push($validateArr, Array("serialNumber","Serial Number",$serialNumber,array("required")));
        array_push($validateArr, Array("manufacturer","Manufacturer",$manufacturer,array("required")));
        array_push($validateArr, Array("yearOfManufactured","Year Of Manufactured",$yearOfManufactured,array("required")));
		array_push($validateArr, Array("costCenter","Cost Center",$costCenter,array("required")));
		

		$result = validate($validateArr);

		if(count($result) > 0){
			$response-> errorList = $result;
		}else{

			$conn = getConn();
			//Get if exist
			$maEQ = "SELECT ma.MachineId FROM machine ma WHERE ma.MachineId='".$machineId."'";
			$maEQResult = mysqli_query($conn, $maEQ);
			
			if($maEQResult == 0){
				throw new Exception("Could not execute isExist");
			}else if(mysqli_num_rows($maEQResult) != 0){
				throw new Exception("Machine exists");
			}

			//Insert Query
			$maQ = "INSERT INTO machine (MachineId,Name,SerialNumber,Manufacturer,YearOfManufactured,CostCenterId) VALUES ('$machineId','$name','$serialNumber','$manufacturer','$yearOfManufactured','$costCenter')";

			$maQResult = mysqli_query($conn, $maQ);
			
			if($maQResult == 0){
				throw new Exception("Could not execute");
			}
			
			$response-> success = "Machine successfully created";
		}
	}catch(Exception $e){
		$response -> error = $e -> getMessage();
	}finally {
		if($conn){
			mysqli_close($conn);
		}
	}
	return $response;
}

function update($response){
	try{
        $machineId = $_POST["machineId"];
		$name= $_POST["name"];
		$serialNumber=$_POST["serialNumber"];
		$manufacturer=$_POST["manufacturer"];
		$yearOfManufactured=$_POST["yearOfManufactured"];
        $costCenter=$_POST["costCenter"];
		
		$validateArr = Array();
		array_push($validateArr, Array("machineId","machine ID",$machineId,array("required")));
		array_push($validateArr, Array("name","Name",$name,array("required")));
		array_push($validateArr, Array("serialNumber","Serial Number",$serialNumber,array("required")));
        array_push($validateArr, Array("manufacturer","Manufacturer",$manufacturer,array("required")));
        array_push($validateArr, Array("yearOfManufactured","Year Of Manufactured",$yearOfManufactured,array("required")));
		array_push($validateArr, Array("costCenter","Cost Center",$costCenter,array("required")));
		
		$result = validate($validateArr);


		if(count($result) > 0){
			$response-> errorList = $result;
		}else{

			$conn = getConn();

			$maQ = "SELECT ma.MachineId, ma.Name, ma.SerialNumber, ma.Manufacturer, ma.YearOfManufactured, cc.Description, ma.CostCenterId FROM machine ma, costcenter cc WHERE cc.CostCenterId = ma.CostCenterId";


			$maQResult = mysqli_query($conn, $maQ);
			
			if($maQResult == 0){
				throw new Exception("Could not execute in SELECT");
			}else if(mysqli_num_rows($maQResult) == 0){
				throw new Exception("Machine not found");
			}

			/*$empQ = "SELECT emp.Name, emp.EmpID, emp.UserName, ag.Description, emp.Shift, emp.UserId, emp.AccessGroupId FROM employee emp, access_group ag WHERE ag.AccessGroupId != emp.AccessGroupId";
			$empQResult = mysqli_query($conn, $empQ);
			
			if($empQResult == 0){
				throw new Exception("Could not execute");
			}else if(mysqli_num_rows($empQResult) != 0){
				throw new Exception("Employee exists");
			}*/

			$maQ = "UPDATE machine SET Name='".$name."', SerialNumber='".$serialNumber."', CostCenterId=$costCenter, Manufacturer='".$manufacturer."', YearOfManufactured='".$yearOfManufactured."' WHERE MachineId=$machineId";
			
			$maQResult = mysqli_query($conn, $maQ);
			
			if($maQResult == 0){
				throw new Exception("Could not execute");
			}
			
			$response-> success = "Machine successfully updated";
		}
	}catch(Exception $e){
		$response -> error = $e -> getMessage();
	}finally {
		if($conn){
			mysqli_close($conn);
		}
	}
	return $response;
}

function delete($response){
	try{
		$machineId = $_POST["machineId"];

		$conn = getConn();

		$maQ = "DELETE FROM machine WHERE MachineId = $machineId";
		$maQResult = mysqli_query($conn, $maQ);
		
		if($maQResult == 0){
			throw new Exception("Could not execute");
		}
		
		$response-> success = "Machine successfully deleted";
		
	}catch(Exception $e){
		$response -> error = $e -> getMessage();
	}finally {
		if($conn){
			mysqli_close($conn);
		}
	}
	return $response;
}

?>
