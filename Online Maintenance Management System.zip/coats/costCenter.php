<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	  <script src="coats.js"></script>
     <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="modules/bootstrap/dist/css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="modules/font-awesome/css/font-awesome.min.css">
    <style type="text/css">

    .modal {
	/*display: none; Hidden by default */
	position: fixed; /* Stay in place */
    z-index: 2000; /* Sit on top */
	padding-top: 100px; /* Location of the box */
	left: 0;
	top: 0;
	width: 100%; /* Full width */
	height: 100%; /* Full height */
	overflow: auto; /* Enable scroll if needed */
	background-color: rgb(0,0,0); /* Fallback color */
	background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    }

    /* Modal Content */
	.modal-content {
	background-color: #0099ff;
	margin: 100px;
    margin-left: 300px;
	padding: 20px 25px 10px;
	border: 1px solid #888;
	width: 100%;
    }
    h3{
    border-top: 1px solid #C0C0C0;
    border-bottom:1px solid #C0C0C0;
    border-left: 600px;
    border-right: 600px;
    margin:0;
    padding: 0 0 5px;
    text-align: center;
    font-size: 15px;
    }
    .options input[type="submit"]{
    border: none;
	outline: none;
	height: 40px;
	width: 100px;
	background:#00008B;
	color:#fff;
	font-size: 14px;
	font-weight: bold;
	margin-left: 20%;
	align-items: justify;
	margin-top: 3%;			
    }
	.options input[type="button"]{
	border: none;
	outline: none;
	height: 40px;
	width: 100px;
	background:#00008B;
	color:#fff;
	font-size: 14px;
	font-weight: bold;
	margin-left: 5%;
	}
	.options input[type="submit"]:hover{
	cursor: pointer;
	background: #0000FF;
	color: #000;
	}
	.options input[type="button"]:hover{
	cursor: pointer;
	background: #0000FF;
	color: #000;
	}
    </style>
</head>


<body>
    <div class="col-12">
        <div class="col-12 col-sm-5 offset-3">
            <!-- <div class="row row-content">
                <img src="logo.bmp" class="logo">
            </div> -->
	      	<!-- Modal content-->
	      	<div class="modal-content">
            <form class="form-content" method="post" action="validate.php">
                <div class="col-12">
                    <h2><b>Cost Center</b></h2>
                </div><br>

                <div class="form-group row">
                        <label for="costcenterId" class="col-12 col-md-3 col-form-label"> Cost Center ID*</label>
                        <div class="col-md-8">
                            <input type="text" class="form-control" id="costcenterId" name="costcenterId" placeholder="Cost Center ID">

                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="name" class="col-12 col-md-3 col-form-label"> Cost Center Name*</label>
                        <div class="col-md-8">
                            <input type="text" class="form-control" id="name" name="name" placeholder="Cost Center Name">
                        </div>
                    </div>
                    <div class="form-group row">
                            <button type="button" class="btn btn-secondary btn-lg ml-auto" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary btn-lg ml-1" onclick="crudOption=1;confsubmit();" id="submit">Add Details</button>
                    </div>
            </form>
        </div>
        </div>
    </div>

    <title>COATS: Cost Center</title>

	<script type="text/javascript" src="./dt2/jquery-3.5.1.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
	<script type="text/javascript" src="./dt2/datatables.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>	
    <script>
	function submit(){
      var costcenterId = document.getElementById("costcenterId").value;
      var name = document.getElementById("name").value;

      var formData = new FormData();
      formData.append("costcenterId", costcenterId);
      formData.append("name", name);

      var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
              var resp = JSON.parse(this.responseText);
              if(resp["error"]){
                  //alertModal("Error", resp["error"]);                     
                  alert(resp["error"]);
              }else if(resp["success"]){
                //alertModal("Success", resp["success"]);
                window.location=resp["success"];
              }else if(resp["errorList"]){
                  populateErrors(resp["errorList"]);
              }else{
                  alert("Unexpected error");
              }
           }
        };
        xhttp.open("POST", "costCenterController.php", true);
        xhttp.send(formData);


    }
    </script>
</body>
</html>
