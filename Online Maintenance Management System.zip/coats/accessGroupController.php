<?php

session_start();
$_SESSION['message']='';
$mysqli=new mysqli('localhost','root','','coats');
    
require("connection.php");
require("validate.php");


			$accessgroupId = $mysqli->real_escape_string($_POST["accessgroupId"]);	
            $name = $mysqli->real_escape_string($_POST['name']);

			//get DB connection instance and execute query
            $conn = getConn();
            $_SESSION['userName']=$userName;

			$agQ = "INSERT INTO accessgroup (AccessGroupId, Description) VALUES ('$accessgroupId','$name')";
            $agQResult = mysqli_query($conn, $agQ);
            
            if ($mysqli->query($agQResult)==true) {
                $_SESSION['message']="Submission successful!";
			    header("location:home.php");
		    }else{
			    $_SESSION['message']="Submission failed.";
            }
?>