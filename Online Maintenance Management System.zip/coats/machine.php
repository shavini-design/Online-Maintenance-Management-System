<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	  <script src="coats.js"></script>
     <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="modules/bootstrap/dist/css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="modules/font-awesome/css/font-awesome.min.css">

    <!-- <link rel="stylesheet" href="modules/bootstrap-social/bootstrap-social.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.17.1/dist/bootstrap-table.min.css">
    
    <link rel="stylesheet" href="modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="modules/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="modules/bootstrap-social/bootstrap-social.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.17.1/dist/bootstrap-table.min.css"> -->
    <!-- <link rel="stylesheet" href="./dt2/Bootstrap-4-4.1.1/css/datatables.min.css">
    <link rel="stylesheet" href="./dt2/bootstrap.min.css"> -->

		<style>
			.tableDiv{
				background-color: white;

			}

			.modal {
				display: none; /* Hidden by default */
				position: fixed; /* Stay in place */
				z-index: 2000; /* Sit on top */
				padding-top: 100px; /* Location of the box */
				left: 0;
				top: 0;
				width: 100%; /* Full width */
				height: 100%; /* Full height */
				overflow: auto; /* Enable scroll if needed */
				background-color: rgb(0,0,0); /* Fallback color */
				background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
			}

			/* Modal Content */
			.modal-content {
				background-color: #fefefe;
				margin: auto;
				padding: 20px;
				border: 1px solid #888;
				width: 100%;
			}

			/* The Close Button */
			.close {
				color: #aaaaaa;
				float: right;
				font-size: 28px;
				font-weight: bold;
			}

			.close:hover,
			.close:focus {
				color: #000;
				text-decoration: none;
				cursor: pointer;
			}
			.options{
				width:1000px;
				height: 90px;
				background-color: #fff;
				color: #00008B;
				left: 50%;
				box-sizing:border-box;
				padding: 1px 50px;
				border-spacing: inherit;
				font-family: sans-serif;
				font-size: 15px;
				font-weight: bold;
				text-align: left;
				background-size: cover;
				margin :10px;
			}
			.options input[type="submit"]{
				border: none;
				outline: none;
				height: 40px;
				width: 100px;
				background:#00008B;
				color:#fff;
				font-size: 14px;
				font-weight: bold;
				margin-left: 20%;
				align-items: justify;
				margin-top: 3%;
			}
			.options input[type="button"]{
				border: none;
				outline: none;
				height: 40px;
				width: 100px;
				background:#00008B;
				color:#fff;
				font-size: 14px;
				font-weight: bold;
				margin-left: 5%;
			}
			.options input[type="submit"]:hover
			{
				cursor: pointer;
				background: #0000FF;
				color: #000;
			}
			.options input[type="button"]:hover
			{
				cursor: pointer;
				background: #0000FF;
				color: #000;
			}
		</style>
		
</head>


<body>
    <div class="container">
        <div class="row">
            <ol class="col-12 breadcrumb">
                <li class="breadcrumb-item"><a href="./home.php">Home</a></li>
                <li class="breadcrumb-item active">Machine</li>
            </ol>
            <div class="col-12">
            	<h3>Machine Details</h3>
			</div>
		</div>
		<div class="col-12">
			<div class="options">
				<!-- <input type="button" onclick="crudOption=1;confCrud();" id="submit" value="Submit">
				<input type="button" onclick="clearAll();" id="refresh" value="Refresh"> -->
				<button type="button" class="btn btn-primary" onclick="crudOption=2;confCrud();"  id="update">Update</button>
				<button type="button" class="btn btn-primary" onclick="crudOption=3;confCrud();"  id="delete">Delete</button>
			</div>
		</div>
            <div class="col-12 tableDiv">
                <table id="tab" class="table table-striped table-bordered" style="width:100%"></table>
                <!-- <a class="btn btn-block btn-sm btn-success" role="button" id="addbtn"><b>Add</b></a> -->
                <button type="button" class="btn btn-block btn-sm btn-success" data-toggle="modal" data-target="#myModal">Open Modal</button>
			</div>
			
			<!-- <script type="text/javascript">
				setup();
			</script> -->
    </div>

    	<!-- Modal -->
		<!-- Modal -->
	  	<div class="modal fade modal-lg" id="myModal" role="dialog">
	    	<div class="modal-dialog">
	    
	      	<!-- Modal content-->
	      	<div class="modal-content">
	        	<div class="modal-header">
	          		<button type="button" class="close" data-dismiss="modal">&times;</button>
	          		<h4 class="modal-title">Fill out machine details</h4>
	        	</div>
	        	<div class="modal-body">
	          
	          		<!-- <form> -->
	                <div class="form-group row">
	                    <label for="machineId" class="col-12 col-md-4 col-form-label">Machine ID</label>
	                    	<div class="col-md-10">
	                        	<input type="text" class="form-control" id="machineId" name="machineId" placeholder="Machine ID">
	                    	</div>
	                </div>
	                <div class="form-group row">
	                    <label for="name" class="col-12 col-md-4 col-form-label">Name</label>
	                    	<div class="col-md-10">
	                        	<input type="text" class="form-control" id="name" name="name" placeholder="Name">
	                   		</div>
	                </div>
	                <div class="form-group row">
	                    <label for="serialNumber" class="col-12 col-md-4 col-form-label">Serial Number</label>
	                    	<div class="col-md-10">
	                        	<input type="text" class="form-control" id="serialNumber" name="serialNumber" placeholder="Serial Number">
	                    	</div>
	                </div>
	                <div class="form-group row">
	                    <label for="manufacturer" class="col-12 col-md-4 col-form-label">Manufacturer</label>
	                    	<div class="col-md-10">
	                        	<input type="text" class="form-control" id="manufacturer" name="manufacturer" placeholder="Manufacturer">
	                    	</div>
                    </div>
                    <div class="form-group row">
	                    <label for="yearOfManufactured" class="col-12 col-md-4 col-form-label">Year of Manufactured</label>
	                    	<div class="col-md-10">
	                        	<input type="date" class="form-control" id="yearOfManufactured" name="yearOfManufactured" placeholder="year of Manufactured">
	                    	</div>
	                </div>
	                <div class="form-group row">
	                    <label for="costCenter" class="col-12 col-md-4 col-form-label">Cost Center</label>
	                    	<div class="col-md-5">
	                        	<select class="form-control">
                                <option value="DH">DH</option>
  				                <option value="FIN">FIN</option>
  				                <option value="ETP">ETP</option>
	                        	</select>
	                    	</div>
	                </div>
	               
					<!-- </form> -->
					<div class="form-group row">
						<div class="offset-md-2 col-md-10">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>   	
							<button type="submit" class="btn btn-primary" onclick="crudOption=1;confCrud();" id="submit">Add Details</button>
						</div>
					</div>
					<!-- <script type="text/javascript">
						setup();
					</script> -->
	        	</div>
	        	<div class="modal-footer">
	          		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        	</div>
	      	</div>
	    	</div>
	  	</div>

    <!-- <div class="addModal" id="addModal" class="modal fade" role="dialog">
        <div class="modal-dialog modal-lg" role="content">    
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Fill out your details</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="col-12 col-md-9">
                    
                </div>
                </div>
            </div>
        </div>
    </div> -->

    <title>COATS: Machine</title>

	<script type="text/javascript" src="./dt2/jquery-3.5.1.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
	<script type="text/javascript" src="./dt2/datatables.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>	
    <script>
		//crudOption 1 = create, 2 = update, 3 = delete
		var crudOption = 0;
		var inputList = ["Machine ID","Name","Serial Number","Manufacturer","Year of Manufactured","Cost Center"];

		function clearAll(){
			clearList(inputList);
			$("#costCenter").val("DH");
		}

		function crud(){
			var xhttp = new XMLHttpRequest();

			if((crudOption == 2 || crudOption == 3) && $("#machineId").val().trim() == ""){
				alertModal("Error", "Please select a record");
				return;
			}

			var formData = new FormData();
			if(crudOption == 1){
				formData.append("method" , "create");
	        }else if(crudOption == 2){
	        	formData.append("method" , "update");
	        }else if(crudOption == 3){
	        	formData.append("method" , "delete");
	        } 

	        if(crudOption == 1 || crudOption == 2){
				formData.append("machineId" , $("#machineId").val());
	        	formData.append("name" , $("#name").val());
				formData.append("serialNumber" , $("#serialNumber").val());
				formData.append("manufacturer" , $("#manufacturer").val());
				formData.append("yearOfManufactured" , $("#yearOfManufactured").val());
				formData.append("costCenter" , $("#costCenter").val());
	        }
	        if(crudOption == 2 || crudOption == 3){
	        	formData.append("machineId" , $("#machineId").val());
			}
			/////////////////////////////////////////////////////////////
	        xhttp.onreadystatechange = function() {
	            if (this.readyState == 4 && this.status == 200) {
	                var resp = JSON.parse(this.responseText);
	                if(resp["error"]){
	                    alert("Error : "+resp["error"]);                     
	                }else if(resp["success"]){
	                	alert("Success :"+resp["success"]);
	                	getTableData();
	                	clearAll();
	                }else if(resp["errorList"]){
	                    printErrors(resp["errorList"]);
	                }else{
	                    alert("Error : Unexpected error");
	                }
	           }
	        };
	        xhttp.open("POST", "machineController.php", true);
	        xhttp.send(formData);
		}

		function getTableData(){
	       	var xhttp = new XMLHttpRequest();

	        var formData = new FormData(); 
			formData.append("method" , "get");
			////////////////////////////////////////////////////////////////////
            //designation drop down come from another page
	        xhttp.onreadystatechange = function() {
	            if (this.readyState == 4 && this.status == 200) {
	                var resp = JSON.parse(this.responseText);
	                if(resp["error"]){
	                    alert("Error : "+resp["error"]);                          
	                }else if(resp["success"]){
	                	drawTable("tab", resp["success"]);
	                }else if(resp["errorList"]){
	                    printErrors(resp["errorList"]);
	                }else{
	                    alert("Error : Unexpected error");
	                }
	           }
	        };
	        xhttp.open("POST", "machineController.php", true);
	        xhttp.send(formData);
		}

		function getCostCenter(){
	       	var xhttp = new XMLHttpRequest();

	        var formData = new FormData(); 
			formData.append("method" , "get");
			/////////////////////////////////////////////////////////////////////
	        xhttp.onreadystatechange = function() {
	            if (this.readyState == 4 && this.status == 200) {
	                var resp = JSON.parse(this.responseText);
	                if(resp["error"]){
	                    alert("Error : "+resp["error"]);                          
	                }else if(resp["success"]){
	                	createSelect("costCenter", resp["success"]);
	                }else if(resp["errorList"]){
	                    printErrors(resp["errorList"]);
	                }else{
	                    alert("Error : Unexpected error");
	                }
	           }
	        };
	        xhttp.open("POST", "costCenterController.php", true);
	        xhttp.send(formData);
		}

		//let table1 = null;
		function setup(){
			table1 = $('#tab').DataTable( {
		    	data: [],
		        columns: [
                    { title: "Machine Id"},
		            { title: "Name"},
		            { title: "Serial Number"},
		            { title: "Manufacturer"},
		            { title: "Year of Manufactured"},
		            { title: "Cost Center"},
                    //{ title: "Cost Center Id"},                   
		        ],
		       // columnDefs: [ {"targets": [6], "searchable": false, "visible": false} ] 
		    } );
		    
		    $('#tab tbody tr').mouseover(function() {
		    	$(this).addClass('tab-row-hover');
		    });
		    $('#tab tbody tr').mouseout(function() {
		        $(this).removeClass('tab-row-hover');
		    }); 
		   
		    $('#tab tbody').on( 'click', 'tr', function () {
		    	    table1.$('tr.tab-row-selected').removeClass('tab-row-selected');
			        $(this).addClass('tab-row-selected');
		 	        
		 	        var rowData = table1.row( this ).data();
		 	        onRowClick(rowData);
		    	
		    } );

		    function onRowClick(data){
		    	$("#machineId").val(data[0]);
                $("#name").val(data[1]);
		    	$("#serialNumber").val(data[2]);
		    	$("#manufacturer").val(data[3]);
		    	$("#yearOfManufactured").val(data[4]);
		    	$("#costCenter").val(data[5]);
               // $("#costCenterId").val(data[6]);

                alert(data);

		    }

			getCostCenter();
			getTableData();
			
		}

        setup();

    </script>
    
</body>
</html>