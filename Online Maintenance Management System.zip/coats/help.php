<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	  <script src="coats.js"></script>
     <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="modules/bootstrap/dist/css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="modules/font-awesome/css/font-awesome.min.css">
    <style type="text/css">
        body{
            margin:0;
            padding:0;
            background: url(image17.jpg);
            width: 100%;
            height: 650px;
            background-size: cover;
            background-position: center;
            font-family: sans-serif;
        }
        .modal-content {
            margin: 50px;
            margin-left: 250px;
            padding: 20px 30px 10px;
            border: 1px solid #888;
            width: 100%;
            }
    </style>
</head>
<body>
<div class="col-12">
        <div class="col-12 col-sm-8 offset-3">
            <!-- <div class="row row-content">
                <img src="logo.bmp" class="logo">
            </div> -->
            <!-- Modal content-->
	      	<div class="modal-content">
                    <div class="col-12">
                    <h3>Coats Thread Exports Pvt(Ltd)</h3><br>
                    <h2><b>Want Help?</b></h2><br>
                    <p>System users: Administrator, Managers, Engineers, Technicians</p>
                    <p>Contact Numbers for any query:</p>
                    <p>Sandun: 0772345450</p>
                    <p>Viraj: 0722312341</p>
                    <p>Email: abc@gmail.com</p>
</body>