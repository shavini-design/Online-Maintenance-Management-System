function confCrud(){
	var msg = "";
	if(crudOption == 1){
		msg =  "Create record?";
    }else if(crudOption == 2){
    	msg = "Update record?";
    }else if(crudOption == 3){
    	msg = "Delete record?";
    } 
    var proceed = confirm(msg);
    if(proceed){
    	crud();
    }
}

function confCrud2(){
	var msg = "";
	if(crudOption == 1){
		msg =  "Create record?";
    }else if(crudOption == 2){
    	msg = "Update record?";
    }else if(crudOption == 3){
    	msg = "Delete record?";
    } 
    var proceed = confirm(msg);
    if(proceed){
    	crud2();
    }
}
function confsubmit(){
	var msg = "";
	if(crudOption == 1){
		msg =  "Create record?";
    }
    var proceed = confirm(msg);
    if(proceed){
    	submit();
    }
}

function printErrors(errorList){
	for(var x=0; x<errorList.length ;x++){
		try{
			var error = errorList[x];
			loadError(error[0]+"Error", error[1]);			
		}catch(e){
			console.log(e);
		}
	}
}

function loadError(id, msg){
	id = "#"+id;
	$(id).html(msg);
}

function clearError(id){
	id = "#"+id;
	$(id).html("");
}

function clearSelect(selectList){
	for(var x=0 ; x<selectList.length ; x++){
		$("#"+selectList[x]).html("");
		$("#"+selectList[x]).val(null);
	}
}

function createSelect(id, data){
	var list = [];
	list.push(id);
	clearSelect(list);

	var option = document.createElement("OPTION");
	option.value = "";
	option.innerHTML = "--SELECT--";
	$("#"+id).append(option);		

	for(var x=0 ; x<data.length ; x++){
		option = document.createElement("OPTION");
		option.value = data[x][0];
		option.innerHTML = data[x][1];
		$("#"+id).append(option);
	}
}

function clearList(list){
	for(var x=0 ; x<list.length ; x++){
		clearInput(list[x]);
		clearError(list[x]);
	}
}

function clearInput(id){
	try{
		$("#"+id).val("");
	}catch(e){		
		console.log(e);
	}
}

function enableAll(list){
	for(var x=0; x<list.length ;x++){
		$("#"+list[x]).prop("disabled",false);
	}
}

function disableAll(list){
	for(var x=0; x<list.length ;x++){
		$("#"+list[x]).prop("disabled",true);
	}
}

function drawTable(id,data){
	console.log(data);
	$('#'+id).dataTable().fnClearTable();
	if(data != null && data.length>0){
		$('#'+id).dataTable().fnAddData(data);	
	}
}


function contains(array,val){
	for(var x = 0 ; x<array.length ; x++){
		if(array[x] == val){
			return true;
		}
	}
	return false;
}

function unformatNo(val){
	if(val.match(/[^\,\.0-9]+/g)){
		return "NaN";
	}else{		
		return parseFloat(parseFloat(val.replace(/,/g ,'')).toFixed(2));
	}
}

function formatNo(val){
	if(isNaN(val)){
		return "NaN";
	}else{
		val = String(val);
		var dot = val.split(".");
		var rhs = "00";
		if(dot.length > 1){
			rhs = dot[1].substring(0,2);
		}
		var newLhs = "";
		var lhs = dot[0];
		if(lhs == ""){
			lhs = "0";
		}
		for(var x = lhs.length ; x>0; x-=3){
			if(x-3 <= 0){
				newLhs = lhs.substring(0,x)+newLhs;
			}else{
				newLhs = ","+lhs.substring(x-3,x)+newLhs;
			}
		}
		return (newLhs+"."+rhs);	
	}
}
