
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

     <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="bootstrap-social/bootstrap-social.css">
    <link rel="stylesheet" href="css/styles.css">
<style>
.nav-bar{
  width: 100%;
  height: 0;
  font-family: sans-serif;
  color:navy;
  margin-left: 0;
  font-size: 12px;
  font-weight: bold;
  text-align: justify;  
  
}
.main-nav{
  
  width: 14.20%;
  height: 100vh;
  float: left;
  background:dodgerblue;
  list-style: none;
  font-family: sans-serif;

  margin-top: 50px;
  font-size: 15px;
  font-weight: bold;
  text-align: justify;
}
.main-nav-ul{
  list-style: none;
  text-decoration-line: none;
  margin-top: 10px;
  color: white;
  
  
}
.main-nav a{
  display: block;
  text-transform: uppercase;
  letter-spacing: .05em;
  color: lightgrey;
  size: 20px;
  padding:15px 0px 10px 0px;
  border-bottom: 2px solid lightblue;
}
.main-nav a:hover{
  background-color: midnightblue;
  text-decoration-line: none;
}
.target{
  width: 85.78%;
  height: 92vh;
  float: right;
  margin-top: 50px;
  background: lightblue;
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
  border-left: 5px solid lightblue;
}

</style>
 
    <title>COATS: Home page</title>

</head>
<body>
    <div class="nav-bar">
        Maintenance Management
    </div>
        
        <div class="main-nav">
            <ul class="main-nav-ul">
                <li><a href="./backnew.jpg" target="frame1"><span class="fa fa-home fa-lg"></span> Home</a></li>
                <li><a href="./register.php" target="frame1"><span class="fa fa-user-plus fa-lg"></span> Register</a></li>
                <li><a href="./workorder.php" target="frame1"><span class="fa fa-file-text fa-lg"></span> Work Order</a></li>
                <li><a href="./spareparts.php" target="frame1"><span class="fa fa-gears fa-lg"></span> Spareparts</a></li>
                <li><a href="./employee.php" target="frame1"><span class="fa fa-user fa-lg"></span> Employee</a></li>
                <li><a href="./machine.php" target="frame1"><span class="fa fa-plug fa-lg"></span> Machine</a></li>
                <li><a href="./costCenter.php" target="frame1"><span class="fa fa-university fa-lg"></span> Cost Center</a></li>
                <li><a href="./accessGroup.php" target="frame1"><span class="fa fa-users fa-lg"></span>AccessGroup</a></li>
                <li><a href="#" target="frame1"><span class="fa fa-bar-chart fa-lg"></span> Reports</a></li>
                <li><a href="./help.php" target="frame1"><span class="fa fa-info-circle fa-lg"></span> Help</a></li>
                <li><a href="./logout.php"><span class="fa fa-sign-out fa-lg"></span> Logout</a></li>
            </ul>
        </div>
        <div class="target">
        <iframe src="./backnew.jpg" name="frame1" id="frame1" style="width: 100%;height: 100vh; float: right;"></iframe>
        </div>
   
    </div>
</body>
</html>       