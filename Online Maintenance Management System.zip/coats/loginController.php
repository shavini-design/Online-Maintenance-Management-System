<?php
require("connection.php");
require("validate.php");

//variable declaration & assign vslues for http post method
$userName = $_POST["userName"];
$password = $_POST["password"];

//variable to print errors
$error = array();

//assgin values and convert to json format
$response = new stdClass();
//$connection = null;
try{
    if(count($error) > 0){
        $response->error = $error;
    }else{
        $connection = getConn();
        
        //$password = hash("sha256",$password);
        $password = md5($_POST['password']);
        $loginQuery = "SELECT UserName, Password FROM register WHERE UserName='$userName' AND Password='$password'";
        //result after querying
        $loginResult = mysqli_query($connection,$loginQuery);
    
        //if 1 result exists
        if(mysqli_num_rows($loginResult) == 1){

            while($row = mysqli_fetch_row($loginResult)){
                session_start();
                $_SESSION["UserName"] = $row['0'];
                $_SESSION["Password"] = $row['1'];
            }
            //set home page url to response object success key
            $response->success = "home.php";
        }else{
            //set error message user not found to response object error key
            $response->error = "User not found";
        }
    }

}catch(Exception $exception){
    $response->error = "Internal error";
} finally {
    if($connection != null){
        closeConenction($connection);
    }
}

//conversion of json string and echo/pass to frontend as response text
echo json_encode($response);
?>
