<?php
error_reporting(E_ERROR | E_PARSE);
function getConn(){
    $servername="localhost";
    $username="root";
    $password="";
    $dbname="coats";

    $connection=mysqli_connect($servername,$username,$password,$dbname);

    if (!$connection){
        //die("Connection failed: ".mysqli_connect_error());
        throw new Exception("Connection failed");
    }else{
        return $connection;
	}
}

function closeConenction($connection){
    mysqli_close($connection);
}

?>